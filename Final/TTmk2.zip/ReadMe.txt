//  Blake Hershberger
//  7-Mar-2021
//  readme

//  1. The program plays Tic-Tac-Toe
//  2. Follow it's commands
//  3. ??????
//  4. Profit

Files:
	TTmk2.java: Game file, when run plays a single game of Tic-Tac-Toe against the computer
	meme.txt: contains ascii of "wat" lady
	Readme.txt

